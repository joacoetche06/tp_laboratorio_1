﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Lapiz : IAcciones
    {
        private float tamanioMina;
        public ConsoleColor Color { get => ConsoleColor.Gray; set => throw new NotImplementedException(); }//si es set lanza excepcion xq no se puede cambiar
        public float UnidadesDeEscritura { get => this.tamanioMina; set => this.tamanioMina = value; }

        public Lapiz(int unidades)
        {
            this.tamanioMina = unidades;
        }

        EscrituraWrapper IAcciones.Escribir(string texto)
        {
            int caracteres = texto.Length;
            if (caracteres > 0)
            {
                this.tamanioMina -= caracteres * 0.1f;
            }

            return new EscrituraWrapper(texto, ConsoleColor.Gray);
        }

        bool IAcciones.Recargar(int unidades)
        {
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            return $"Lapiz - color {ConsoleColor.Gray} - tamaño de mina: {this.tamanioMina}";
        }
    }
}
