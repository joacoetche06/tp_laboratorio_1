﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class CartucheraMulituso
    {
        public List<IAcciones> lista;

        public bool RecorrerElementos()
        {
            bool retorno = false;
            foreach(IAcciones elemento in lista)
            {
                elemento.UnidadesDeEscritura -= 1;
                if(elemento.UnidadesDeEscritura == 0)
                {
                    elemento.Recargar(20);
                }
                retorno = true;
            }
            return retorno;
        }
    }
}
